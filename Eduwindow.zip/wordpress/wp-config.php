<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'eduwindow');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '!/|fGmu^^D9R5#OYHil1(>WoQ/4ba&ToHKbVH.31r]DE>80UJg5_7LcjK+mSex{U');
define('SECURE_AUTH_KEY',  ',?;fV+<Fqv0JJwiMe?pbJ^r X:@=aeSN1IOM~.kuX8mMj8hX}/Xp^u(`J4Wm>FR^');
define('LOGGED_IN_KEY',    '>K(2)|Un2VF>t9{X|gV/4V* :U6,7tzk]BOZTeIKe$Lg;mk(g(ArDa{{ =]H-FWp');
define('NONCE_KEY',        'qzn{GR/nF>`KqLrBS+`$z]=D%H9=dF8N&wrpzetFP%d(cvp7_E//`pD@1QJ=E?:-');
define('AUTH_SALT',        '.%%Xuyo>P<>o#AjH:wi>,9t]}`x{ubgCwE9J[-NCWjR2*dj*9q,9fMou*Db_dxJe');
define('SECURE_AUTH_SALT', 'tT8;)3gm%{6Xq`9nEOhF2[IcJI?;/0R XSS`ZYs2p~`#FzQq-hOI@.BTaHPnIP@]');
define('LOGGED_IN_SALT',   '-yu]>LIj%I:ph@171.pFDV+t,1!#sT}r@Z4/pr>0eSxHp|*-0)mZ94mQH} 3vB79');
define('NONCE_SALT',       'hXrt9g+Ss{a0Al=3]<^pOzB:m;t_#EL,z}YA.??dFK8j,8g4d^[D< m?dMeF3nZ%');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
