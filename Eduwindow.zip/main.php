<!DOCTYPE html>
<!--[if lt IE 7 ]>	<html lang="en-US" class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]>		<html lang="en-US" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]>		<html lang="en-US" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]>		<html lang="en-US" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html lang="en-US" class="no-js"> <!--<![endif]-->
<head>
<meta charset="UTF-8" />

<!-- Title now generate from add_theme_support('title-tag') -->



<!-- STYLESHEET INIT -->
<link href="http://localhost/wordpress/wp-content/themes/mesocolumn/style.css" rel="stylesheet" type="text/css" />

<!-- favicon.ico location -->

<link rel="pingback" href="http://localhost/wordpress/xmlrpc.php" />



<title>EduWindow &raquo; One site for all Your needs..</title>

<link rel="alternate" type="application/rss+xml" title="EduWindow &raquo; Feed" href="http://localhost/wordpress/index.php/feed/" />
<link rel="alternate" type="application/rss+xml" title="EduWindow &raquo; Comments Feed" href="http://localhost/wordpress/index.php/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"http:\/\/s.w.org\/images\/core\/emoji\/72x72\/","ext":".png","source":{"concatemoji":"http:\/\/localhost\/wordpress\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.3.1"}};
			!function(a,b,c){function d(a){var c=b.createElement("canvas"),d=c.getContext&&c.getContext("2d");return d&&d.fillText?(d.textBaseline="top",d.font="600 32px Arial","flag"===a?(d.fillText(String.fromCharCode(55356,56812,55356,56807),0,0),c.toDataURL().length>3e3):(d.fillText(String.fromCharCode(55357,56835),0,0),0!==d.getImageData(16,16,1,1).data[0])):!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g;c.supports={simple:d("simple"),flag:d("flag")},c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.simple&&c.supports.flag||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='theme-my-login-css'  href='http://localhost/wordpress/wp-content/plugins/theme-my-login/theme-my-login.css?ver=6.4.1' type='text/css' media='all' />
<link rel='stylesheet' id='open-sans-css'  href='https://fonts.googleapis.com/css?family=Open+Sans%3A300italic%2C400italic%2C600italic%2C300%2C400%2C600&#038;subset=latin%2Clatin-ext&#038;ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css'  href='http://localhost/wordpress/wp-includes/css/dashicons.min.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='admin-bar-css'  href='http://localhost/wordpress/wp-includes/css/admin-bar.min.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='meteor-slides-css'  href='http://localhost/wordpress/wp-content/plugins/meteor-slides/css/meteor-slides.css?ver=1.0' type='text/css' media='all' />
<link rel='stylesheet' id='default_gwf-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A400%2C400italic%2C600%2C600italic%2C700%2C700italic%2C300%2C300italic&#038;ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='superfish-css'  href='http://localhost/wordpress/wp-content/themes/mesocolumn/lib/scripts/superfish-menu/css/superfish.css?ver=1.6.4.1' type='text/css' media='all' />
<link rel='stylesheet' id='tabber-css'  href='http://localhost/wordpress/wp-content/themes/mesocolumn/lib/scripts/tabber/tabber.css?ver=1.6.4.1' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-cdn-css'  href='http://localhost/wordpress/wp-content/themes/mesocolumn/lib/scripts/font-awesome/css/font-awesome.css?ver=1.6.4.1' type='text/css' media='all' />
<script type='text/javascript' src='http://localhost/wordpress/wp-includes/js/jquery/jquery.js?ver=1.11.3'></script>
<script type='text/javascript' src='http://localhost/wordpress/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.2.1'></script>
<script type='text/javascript' src='http://localhost/wordpress/wp-content/plugins/meteor-slides/js/jquery.cycle.all.js?ver=4.3.1'></script>
<script type='text/javascript' src='http://localhost/wordpress/wp-content/plugins/meteor-slides/js/jquery.metadata.v2.js?ver=4.3.1'></script>
<script type='text/javascript' src='http://localhost/wordpress/wp-content/plugins/meteor-slides/js/jquery.touchwipe.1.1.1.js?ver=4.3.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var meteorslidessettings = {"meteorslideshowspeed":"2000","meteorslideshowduration":"5000","meteorslideshowheight":"200","meteorslideshowwidth":"940","meteorslideshowtransition":"fade"};
/* ]]> */
</script>
<script type='text/javascript' src='http://localhost/wordpress/wp-content/plugins/meteor-slides/js/slideshow.js?ver=4.3.1'></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://localhost/wordpress/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://localhost/wordpress/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.3.1" />
		<link rel='alternate' type='application/rss+xml' title="Forums RSS" href="http://localhost/wordpress/wp-content/plugins/forum-server/feed.php?topic=all" />
		<link rel='stylesheet' type='text/css' href="http://localhost/wordpress/wp-content/plugins/forum-server/skins/wpf-2.0/style.css"  />



		<script language="JavaScript" type="text/javascript" src="http://localhost/wordpress/wp-content/plugins/forum-server/js/script.js"></script>

	<script language="JavaScript" type="text/javascript">
		window.skinurl = 'http://localhost/wordpress/wp-content/plugins/forum-server/skins/wpf-2.0';		function wpf_confirm(){
			var answer = confirm ('Remove this post?');
			if (!answer)
				return false;
			else
				return true;
		}

		</script>



	<style type='text/css' media='all'>body {font-family: 'Open Sans', sans-serif;font-weight: 400;}
#siteinfo div,h1,h2,h3,h4,h5,h6,.header-title,#main-navigation, #featured #featured-title, #cf .tinput, #wp-calendar caption,.flex-caption h1,#portfolio-filter li,.nivo-caption a.read-more,.form-submit #submit,.fbottom,ol.commentlist li div.comment-post-meta, .home-post span.post-category a,ul.tabbernav li a {font-family: 'Open Sans', sans-serif;font-weight: 600;}
#main-navigation, .sf-menu li a {font-family: 'Open Sans', sans-serif;font-weight: 600;}










#siteinfo {position:absolute;top:15%;left:2em;}
#topbanner {position:absolute;top:15%;right:2em;}
#custom #custom-img-header {margin:0;}

.content, #right-sidebar {}


#post-entry div.post-thumb.size-thumbnail {float:left;width:150px;}
#post-entry article .post-right {margin:0 0 0 170px;}



</style><style type='text/css' media='screen'>.gravatar_recent_comment li, .twitterbox li { padding:0px; font-size: 1.025em; line-height:1.5em;  }
.gravatar_recent_comment span.author { font-weight:bold; }
.gravatar_recent_comment img { width:50px; height:50px; float:left; margin: 0 10px 0 0; }
ul.recent-postcat li {position:relative;border-bottom: 1px solid #EAEAEA;padding: 0 0 0.5em !important;margin: 0 0 1em !important;}
ul.recent-postcat li:last-child,ul.item-list li:last-child,.avatar-block li:last-child  { border-bottom: none;  }
ul.recent-postcat li .feat-post-meta { margin: 0px 0 0 68px; }
ul.recent-postcat li.has_no_thumb .feat-post-meta { margin: 0px; }
ul.recent-postcat img {background: white;padding: 5px;margin:0px;border: 1px solid #DDD;}
#custom #right-sidebar ul.recent-postcat li .feat-post-meta .feat-title {margin: 0;}
#custom #right-sidebar ul.recent-postcat li .feat-post-meta .feat-title {width: 100%;font-size: 1.05em; line-height:1.35em !important;font-weight: bold;}
ul.recent-postcat li .feat-post-meta small { font-size: 0.85em; padding:0; }
ul.recent-postcat li .feat-post-meta small .widget-feat-comment {display:none;}
.bp-searchform {margin: 0px;padding: 5%;float: left;width: 90%;background: white;border: 1px solid #DDD;}
.bp-searchform label {display:none;}
#custom div.medium-thumb {margin:0 0 0.2em;width:99%;overflow:hidden;padding:0 !important;border:0 none !important;}
#custom div.medium-thumb p {text-align:center;margin:0;width:100%;padding:0;border:0 none;height:100%;overflow:hidden;}
#custom div.medium-thumb img {float:none;border:0 none;max-width:100%;margin:0 !important;padding:0 !important;}
ul.recent-postcat li.the-sidefeat-thumbnail img {padding:3px !important;border:1px solid #ddd;}
#custom ul.recent-postcat li.the-sidefeat-thumbnail img:hover {background:white none;padding:3px;border:1px solid #ccc;}
ul.recent-postcat li.the-sidefeat-medium .feat-post-meta {margin: 0;}
</style>	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
<style type="text/css" media="print">#wpadminbar { display:none; }</style>
<style type="text/css" media="screen">
	html { margin-top: 32px !important; }
	* html body { margin-top: 32px !important; }
	@media screen and ( max-width: 782px ) {
		html { margin-top: 46px !important; }
		* html body { margin-top: 46px !important; }
	}
</style>

</head>

<body class="home blog logged-in admin-bar no-customize-support gecko" id="custom">

<div class="product-with-desc secbody">

<div id="wrapper">

<div id="wrapper-main">

<div id="bodywrap" class="innerwrap">

<div id="bodycontent">

<!-- CONTAINER START -->
<div id="container">

<nav class="top-nav iegradient effect-1" id="top-navigation" role="navigation">
<div class="innerwrap">
<ul class="sf-menu"><li class="current_page_item"><a href="http://localhost/wordpress/">Home</a></li><li class="page_item page-item-2 page_item_has_children"><a href="http://localhost/wordpress/index.php/sample-page/">Courses</a><ul class='children'><li class="page_item page-item-25"><a href="http://localhost/wordpress/index.php/sample-page/c-c/">C, C++</a></li><li class="page_item page-item-32"><a href="http://localhost/wordpress/index.php/sample-page/core-java/">Core Java</a></li><li class="page_item page-item-34"><a href="http://localhost/wordpress/index.php/sample-page/java-jeee/">Java,JEEE</a></li><li class="page_item page-item-53"><a href="http://localhost/wordpress/index.php/sample-page/python/">Python</a></li><li class="page_item page-item-39 page_item_has_children"><a href="http://localhost/wordpress/index.php/sample-page/web-languages/">Web Languages</a><ul class='children'><li class="page_item page-item-48"><a href="http://localhost/wordpress/index.php/sample-page/web-languages/javascript/">JavaScript</a></li><li class="page_item page-item-59"><a href="http://localhost/wordpress/index.php/sample-page/web-languages/perl/">Perl</a></li><li class="page_item page-item-46"><a href="http://localhost/wordpress/index.php/sample-page/web-languages/php/">PHP</a></li><li class="page_item page-item-61"><a href="http://localhost/wordpress/index.php/sample-page/web-languages/ruby/">Ruby</a></li></ul></li></ul></li><li class="page_item page-item-88 page_item_has_children"><a href="http://localhost/wordpress/index.php/forum/">Forum</a><ul class='children'><li class="page_item page-item-85"><a href="http://localhost/wordpress/index.php/forum/discussion-board/">Discussion Board</a></li></ul></li><li class="page_item page-item-98"><a href="http://localhost/wordpress/index.php/forumpress/">ForumPress</a></li><li class="page_item page-item-90"><a href="http://localhost/wordpress/index.php/question-papers/">Question papers</a></li></ul>
<div id="mobile-nav">
</div>
</div>
</nav>

<!-- HEADER START -->
<header class="iegradient yes_head" id="header" role="banner">
<div class="header-inner">
<div class="innerwrap">
<div id="siteinfo">
<h1 ><a href="http://localhost/wordpress/" title="EduWindow" rel="home">EduWindow</a></h1 ><p id="site-description">One site for all Your needs..</p>
</div>
<!-- SITEINFO END -->
<div id="custom-img-header"><img src="http://localhost/wordpress/wp-content/uploads/2015/10/images.jpg" alt="EduWindow" /></div></div>
</div>
</header>
<!-- HEADER END -->


<div class="container-wrap">

<!-- NAVIGATION START -->
<nav class="main-nav iegradient" id="main-navigation" role="navigation">
<ul class="sf-menu">	<li class="cat-item cat-item-1"><a href="http://localhost/wordpress/index.php/category/uncategorized/" >Uncategorized</a>
</li>
</ul></nav>
<!-- NAVIGATION END -->



<!-- CONTENT START -->
<div class="content">
<div class="content-inner">


<!-- POST ENTRY START -->
<div id="post-entry">

<div class="post-entry-inner">






<!-- POST START -->
<article class="alt-post feat-thumbnail post-style- post-1 post type-post status-publish format-standard has-post-thumbnail hentry category-uncategorized has_thumb" id="post-1">

<div class='post-thumb in-archive size-thumbnail'><a href="http://localhost/wordpress/index.php/2015/10/16/hello-world/" title="Enter into new way of studying"><img width='150' height='150' class='alignleft img-is-thumbnail' src='http://localhost/wordpress/wp-content/uploads/2015/10/Travancore-Engineering-College-x-150x150.jpg' alt='Uncategorized' title='Enter into new way of studying' /></a></div>
<div class="post-right">
<h2 class="post-title entry-title"><a href="http://localhost/wordpress/index.php/2015/10/16/hello-world/" rel="bookmark" title="Enter into new way of studying">Enter into new way of studying</a></h2>
<div class="post-meta the-icons pmeta-alt">

<span class="post-author vcard"><i class="fa fa-user"></i><a class="url fn n" href="http://localhost/wordpress/index.php/author/vivek/" title="Posts by vivek" rel="author">vivek</a></span>

<span class="entry-date"><i class="fa fa-clock-o"></i><abbr class="published" title="2015-10-16T14:33:33+00:00">October 16, 2015</abbr></span>
<span class="meta-no-display"><a href="http://localhost/wordpress/index.php/2015/10/16/hello-world/" rel="bookmark">Enter into new way of studying</a></span><span class="date updated meta-no-display">2015-10-16T17:23:35+00:00</span>

<span class="post-category"><i class="fa fa-file"></i><a rel="category tag" href="http://localhost/wordpress/index.php/category/uncategorized/" title="View all posts in Uncategorized" >Uncategorized</a></span>
<span class="post-comment last"><i class="fa fa-comment"></i><a href="http://localhost/wordpress/index.php/2015/10/16/hello-world/#comments">1 Comment</a></span>
</div><div class="post-content">
<div class="entry-content">Welcome to E-College ! &nbsp; We offer Online coaching to students via Video calling which support home environment students. We will not force any restriction, pressure on students. We...</div>
<div class="post-more"><a href="http://localhost/wordpress/index.php/2015/10/16/hello-world/" title="Enter into new way of studying">Continue Reading</a></div>
</div>
</div>

</article>
<!-- POST END -->







<div id="post-navigator">
</div>




</div>
</div>
<!-- POST ENTRY END -->


</div><!-- CONTENT INNER END -->
</div><!-- CONTENT END -->



<div id="right-sidebar" class="sidebar right-sidebar">
<div class="sidebar-inner">
<div class="widget-area the-icons">


<div id="tabber-widget"><div class="tabber">
		<div class="tabbertab"><aside id="recent-posts-2" class="widget widget_recent_entries">		<h3>Login</h3>		<ul>
					<li>
				<a href="http://localhost/wordpress/index.php/2015/10/16/hello-world/">Enter into new way of studying</a>
						</li>
				</ul>
		</aside></div><div class="tabbertab"><aside id="recent-comments-2" class="widget widget_recent_comments"><h3>Recent Comments</h3><ul id="recentcomments"><li class="recentcomments"><span class="comment-author-link"><a href='https://wordpress.org/' rel='external nofollow' class='url'>Mr WordPress</a></span> on <a href="http://localhost/wordpress/index.php/2015/10/16/hello-world/#comment-1">Enter into new way of studying</a></li></ul></aside></div><div class="tabbertab"><aside id="archives-2" class="widget widget_archive"><h3>Archives</h3>		<label class="screen-reader-text" for="archives-dropdown-2">Archives</label>
		<select id="archives-dropdown-2" name="archive-dropdown" onchange='document.location.href=this.options[this.selectedIndex].value;'>
			
			<option value="">Select Month</option>
				<option value='http://localhost/wordpress/index.php/2015/10/'> October 2015 &nbsp;(1)</option>

		</select>
</aside></div><div class="tabbertab"><aside id="categories-2" class="widget widget_categories"><h3>Categories</h3><label class="screen-reader-text" for="cat">Categories</label><select name='cat' id='cat' class='postform' >
	<option value='-1'>Select Category</option>
	<option class="level-0" value="1">Uncategorized</option>
</select>

<script type='text/javascript'>
/* <![CDATA[ */
(function() {
	var dropdown = document.getElementById( "cat" );
	function onCatChange() {
		if ( dropdown.options[ dropdown.selectedIndex ].value > 0 ) {
			location.href = "http://localhost/wordpress/?cat=" + dropdown.options[ dropdown.selectedIndex ].value;
		}
	}
	dropdown.onchange = onCatChange;
})();
/* ]]> */
</script>

</aside></div></div></div>
<aside class="widget">
<h3 class="widget-title">Search</h3>
<form role="search" method="get" id="searchform" class="searchform" action="http://localhost/wordpress/">
				<div>
					<label class="screen-reader-text" for="s">Search for:</label>
					<input type="text" value="" name="s" id="s" />
					<input type="submit" id="searchsubmit" value="Search" />
				</div>
			</form></aside>
<aside class="widget widget_recent_entries">
<h3 class="widget-title">Recent Posts</h3>
<ul>	<li><a href='http://localhost/wordpress/index.php/2015/10/16/hello-world/'>Enter into new way of studying</a></li>
</ul>
</aside>
<aside class="widget widget">
<h3 class="widget-title">Pages</h3>
<ul><li class="page_item page-item-2 page_item_has_children"><a href="http://localhost/wordpress/index.php/sample-page/">Courses</a>
<ul class='children'>
	<li class="page_item page-item-25"><a href="http://localhost/wordpress/index.php/sample-page/c-c/">C, C++</a></li>
	<li class="page_item page-item-32"><a href="http://localhost/wordpress/index.php/sample-page/core-java/">Core Java</a></li>
	<li class="page_item page-item-34"><a href="http://localhost/wordpress/index.php/sample-page/java-jeee/">Java,JEEE</a></li>
	<li class="page_item page-item-53"><a href="http://localhost/wordpress/index.php/sample-page/python/">Python</a></li>
	<li class="page_item page-item-39 page_item_has_children"><a href="http://localhost/wordpress/index.php/sample-page/web-languages/">Web Languages</a>
	<ul class='children'>
		<li class="page_item page-item-48"><a href="http://localhost/wordpress/index.php/sample-page/web-languages/javascript/">JavaScript</a></li>
		<li class="page_item page-item-59"><a href="http://localhost/wordpress/index.php/sample-page/web-languages/perl/">Perl</a></li>
		<li class="page_item page-item-46"><a href="http://localhost/wordpress/index.php/sample-page/web-languages/php/">PHP</a></li>
		<li class="page_item page-item-61"><a href="http://localhost/wordpress/index.php/sample-page/web-languages/ruby/">Ruby</a></li>
	</ul>
</li>
</ul>
</li>
<li class="page_item page-item-88 page_item_has_children"><a href="http://localhost/wordpress/index.php/forum/">Forum</a>
<ul class='children'>
	<li class="page_item page-item-85"><a href="http://localhost/wordpress/index.php/forum/discussion-board/">Discussion Board</a></li>
</ul>
</li>
<li class="page_item page-item-98"><a href="http://localhost/wordpress/index.php/forumpress/">ForumPress</a></li>
<li class="page_item page-item-90"><a href="http://localhost/wordpress/index.php/question-papers/">Question papers</a></li>
</ul>
</aside>
<aside class="widget">
<h3 class="widget-title">Tags</h3>
<div class="tagcloud"><ul></ul></div>
</aside>


</div>
</div><!-- SIDEBAR-INNER END -->
</div><!-- RIGHT SIDEBAR END -->
</div><!-- CONTAINER WRAP END -->

</div><!-- CONTAINER END -->

</div><!-- BODYCONTENT END -->

</div><!-- INNERWRAP BODYWRAP END -->

</div><!-- WRAPPER MAIN END -->

</div><!-- WRAPPER END -->





<footer class="footer-bottom">
<div class="innerwrap">
<div class="fbottom">
<div class="footer-left">
Copyright &copy; 2015. EduWindow</div>
<div class="footer-right">
<a target="_blank" href="http://www.dezzain.com/wordpress-themes/mesocolumn/">Mesocolumn</a> Theme by Dezzain</div>
</div>
</div>
</footer>
<!-- FOOTER BOTTOM END -->


</div>
<!-- SECBODY END -->

		<script type="text/javascript" >

			fold();
		function notify(){

			var answer = confirm ('');
			if (!answer)
				return false;
			else
				return true;
		}

		</script>
	<script type='text/javascript' src='http://localhost/wordpress/wp-includes/js/admin-bar.min.js?ver=4.3.1'></script>
<script type='text/javascript' src='http://localhost/wordpress/wp-includes/js/hoverIntent.min.js?ver=1.8.1'></script>
<script type='text/javascript' src='http://localhost/wordpress/wp-content/themes/mesocolumn/lib/scripts/modernizr/modernizr.js?ver=1.6.4.1'></script>
<script type='text/javascript' src='http://localhost/wordpress/wp-content/themes/mesocolumn/lib/scripts/tabber/tabber.js?ver=1.6.4.1'></script>
<script type='text/javascript' src='http://localhost/wordpress/wp-content/themes/mesocolumn/lib/scripts/superfish-menu/js/superfish.js?ver=1.6.4.1'></script>
<script type='text/javascript' src='http://localhost/wordpress/wp-content/themes/mesocolumn/lib/scripts/superfish-menu/js/supersubs.js?ver=1.6.4.1'></script>
<script type='text/javascript' src='http://localhost/wordpress/wp-content/themes/mesocolumn/lib/scripts/custom.js?ver=1.6.4.1'></script>
	<script type="text/javascript">
		(function() {
			var request, b = document.body, c = 'className', cs = 'customize-support', rcs = new RegExp('(^|\\s+)(no-)?'+cs+'(\\s+|$)');

			request = true;

			b[c] = b[c].replace( rcs, ' ' );
			b[c] += ( window.postMessage && request ? ' ' : ' no-' ) + cs;
		}());
	</script>
			<div id="wpadminbar" class="nojq nojs">
							<a class="screen-reader-shortcut" href="#wp-toolbar" tabindex="1">Skip to toolbar</a>
						<div class="quicklinks" id="wp-toolbar" role="navigation" aria-label="Toolbar" tabindex="0">
				<ul id="wp-admin-bar-root-default" class="ab-top-menu">
		<li id="wp-admin-bar-wp-logo" class="menupop"><a class="ab-item"  aria-haspopup="true" href="http://localhost/wordpress/wp-admin/about.php"><span class="ab-icon"></span><span class="screen-reader-text">About WordPress</span></a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-wp-logo-default" class="ab-submenu">
		<li id="wp-admin-bar-about"><a class="ab-item"  href="http://localhost/wordpress/wp-admin/about.php">About WordPress</a>		</li></ul><ul id="wp-admin-bar-wp-logo-external" class="ab-sub-secondary ab-submenu">
		<li id="wp-admin-bar-wporg"><a class="ab-item"  href="https://wordpress.org/">WordPress.org</a>		</li>
		<li id="wp-admin-bar-documentation"><a class="ab-item"  href="https://codex.wordpress.org/">Documentation</a>		</li>
		<li id="wp-admin-bar-support-forums"><a class="ab-item"  href="https://wordpress.org/support/">Support Forums</a>		</li>
		<li id="wp-admin-bar-feedback"><a class="ab-item"  href="https://wordpress.org/support/forum/requests-and-feedback">Feedback</a>		</li></ul></div>		</li>
		<li id="wp-admin-bar-site-name" class="menupop"><a class="ab-item"  aria-haspopup="true" href="http://localhost/wordpress/wp-admin/">EduWindow</a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-site-name-default" class="ab-submenu">
		<li id="wp-admin-bar-dashboard"><a class="ab-item"  href="http://localhost/wordpress/wp-admin/">Dashboard</a>		</li></ul><ul id="wp-admin-bar-appearance" class="ab-submenu">
		<li id="wp-admin-bar-themes"><a class="ab-item"  href="http://localhost/wordpress/wp-admin/themes.php">Themes</a>		</li>
		<li id="wp-admin-bar-widgets"><a class="ab-item"  href="http://localhost/wordpress/wp-admin/widgets.php">Widgets</a>		</li>
		<li id="wp-admin-bar-menus"><a class="ab-item"  href="http://localhost/wordpress/wp-admin/nav-menus.php">Menus</a>		</li>
		<li id="wp-admin-bar-background" class="hide-if-customize"><a class="ab-item"  href="http://localhost/wordpress/wp-admin/themes.php?page=custom-background">Background</a>		</li>
		<li id="wp-admin-bar-header" class="hide-if-customize"><a class="ab-item"  href="http://localhost/wordpress/wp-admin/themes.php?page=custom-header">Header</a>		</li></ul></div>		</li>
		<li id="wp-admin-bar-customize" class="hide-if-no-customize"><a class="ab-item"  href="http://localhost/wordpress/wp-admin/customize.php?url=http%3A%2F%2Flocalhost%2Fwordpress%2F">Customize</a>		</li>
		<li id="wp-admin-bar-comments"><a class="ab-item"  href="http://localhost/wordpress/wp-admin/edit-comments.php" title="0 comments awaiting moderation"><span class="ab-icon"></span><span id="ab-awaiting-mod" class="ab-label awaiting-mod pending-count count-0">0</span></a>		</li>
		<li id="wp-admin-bar-new-content" class="menupop"><a class="ab-item"  aria-haspopup="true" href="http://localhost/wordpress/wp-admin/post-new.php"><span class="ab-icon"></span><span class="ab-label">New</span></a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-new-content-default" class="ab-submenu">
		<li id="wp-admin-bar-new-post"><a class="ab-item"  href="http://localhost/wordpress/wp-admin/post-new.php">Post</a>		</li>
		<li id="wp-admin-bar-new-media"><a class="ab-item"  href="http://localhost/wordpress/wp-admin/media-new.php">Media</a>		</li>
		<li id="wp-admin-bar-new-page"><a class="ab-item"  href="http://localhost/wordpress/wp-admin/post-new.php?post_type=page">Page</a>		</li>
		<li id="wp-admin-bar-new-slide"><a class="ab-item"  href="http://localhost/wordpress/wp-admin/post-new.php?post_type=slide">Slide</a>		</li>
		<li id="wp-admin-bar-new-user"><a class="ab-item"  href="http://localhost/wordpress/wp-admin/user-new.php">User</a>		</li></ul></div>		</li></ul><ul id="wp-admin-bar-top-secondary" class="ab-top-secondary ab-top-menu">
		<li id="wp-admin-bar-search" class="admin-bar-search"><div class="ab-item ab-empty-item" tabindex="-1"><form action="http://localhost/wordpress/" method="get" id="adminbarsearch"><input class="adminbar-input" name="s" id="adminbar-search" type="text" value="" maxlength="150" /><label for="adminbar-search" class="screen-reader-text">Search</label><input type="submit" class="adminbar-button" value="Search"/></form></div>		</li>
		<li id="wp-admin-bar-my-account" class="menupop with-avatar"><a class="ab-item"  aria-haspopup="true" href="http://localhost/wordpress/wp-admin/profile.php">Howdy, vivek<img alt='' src='http://2.gravatar.com/avatar/8ee6b40f60e11a338abde0f67331d839?s=26&#038;d=mm&#038;r=g' srcset='http://2.gravatar.com/avatar/8ee6b40f60e11a338abde0f67331d839?s=52&amp;d=mm&amp;r=g 2x' class='avatar avatar-26 photo' height='26' width='26' /></a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-user-actions" class="ab-submenu">
		<li id="wp-admin-bar-user-info"><a class="ab-item" tabindex="-1" href="http://localhost/wordpress/wp-admin/profile.php"><img alt='' src='http://2.gravatar.com/avatar/8ee6b40f60e11a338abde0f67331d839?s=64&#038;d=mm&#038;r=g' srcset='http://2.gravatar.com/avatar/8ee6b40f60e11a338abde0f67331d839?s=128&amp;d=mm&amp;r=g 2x' class='avatar avatar-64 photo' height='64' width='64' /><span class='display-name'>vivek</span></a>		</li>
		<li id="wp-admin-bar-edit-profile"><a class="ab-item"  href="http://localhost/wordpress/wp-admin/profile.php">Edit My Profile</a>		</li>
		<li id="wp-admin-bar-logout"><a class="ab-item"  href="http://localhost/wordpress/index.php/logout/?_wpnonce=9e629b7000">Log Out</a>		</li></ul></div>		</li></ul>			</div>
						<a class="screen-reader-shortcut" href="http://localhost/wordpress/index.php/logout/?_wpnonce=9e629b7000">Log Out</a>
					</div>

		

</body>

</html>