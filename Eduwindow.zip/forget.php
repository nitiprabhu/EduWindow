<html>
<head >
<title>Forget Password Recovery</title></head>
<style type="text/css">
.status{
background-color: #f5deb3;
position: absolute;
top: 63%;
left: 40%;
font-size:20px;
width: 430px;
}
body{
background-image: url(background.jpg);
}
.tab{
background-color: #f5deb3;
position: absolute;
top: 40%;
left: 40%;
font-size:30px;
padding:4%;
}
input{
font-weight: bold;
font: message-box;
font-size: larger;
background-color: #f4a460;
padding: 10px;	
}
</style><body >
<form method="POST" class="tab">
<table>
<tr>
<td><lable style="font-size:30px;">Email</lable></td><td><input type="text" id="femail" name="femail"></td>
</tr><tr>
<td colspan="2" align="center" ><input type="submit" id="bnsubmit" name="btnsubmit" value="Get Password"></td>
</tr>
</table>
</form>
<p class="status">
<?php 
error_reporting(0);
mysql_connect("localhost","root","");
mysql_select_db("eduwindow");
$email = $_REQUEST["femail"];
$sql = "select * from userstudent where semail='$email'";
$resArr=mysql_query($sql);
$result= mysql_fetch_array($resArr);
if($result!=NULL)
{
mail($email, 'Recover Password', $result[password]);
echo "Password Sussfully sent to Email Address";
}
else if($email!=NULL){
echo "Un-Authorised Email Address";
}
?></p>
</body>
</html>