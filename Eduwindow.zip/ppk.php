<html>
<style type="text/css">

body{
	background-image:url(Penguins.jpg);
	
   scrollbar-3dlight-color:;
   scrollbar-arrow-color: ;
   scrollbar-base-color: ;
   scrollbar-darkshadow-color: ;
   scrollbar-face-color: ;
   scrollbar-highlight-color: ;
   scrollbar-shadow-color: ;
   scrollbar-track-color :#fff000;
}
p{	
background-image:url(Desert.jpg);
text-align: center;
width: 80%;
font-size: 50;
font-weight: bold;
position: absolute;
left: 10%
}
</style>
<head>
<title>WordPress</title>
<body>
<p>Title</p></body>
</html>