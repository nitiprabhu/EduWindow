<?php
$username = $_REQUEST["username"];
$password = $_REQUEST["password1"];
$pwlen = strlen($password);
$crpt = "";
for($i=0;$i<=$pwlen/2;$i++)
{
	$crpt="$crpt$password[$i]";
}
$crpt="$crpt$password";
for($i=($pwlen/2);$i<$pwlen;$i++)
{
	$crpt="$crpt$password[$i]";
}

mysql_connect("localhost","root","");
mysql_select_db("eduwindow");
$sql1 = "select * from userstudent where sid='$username' and password='$crpt'";
$sql2 = "select * from userstudent where semail='$username'and password='$password'";
$sql3 = "select * from userstudent where mobnum='$username' and password='$password'";

$resArr1=mysql_query($sql1);
$resArr2=mysql_query($sql2);
$resArr3=mysql_query($sql3);
$result1= mysql_fetch_array($resArr1);
$result2= mysql_fetch_array($resArr2);
$result3= mysql_fetch_array($resArr3);
if($result=($result1|$result2|$result3)){
echo "<script type=text/javascript>
                     function f()
                      {
                         document.getElementById('f1').submit();
                      }
                    </script>
                    <body onload=f()>
                    <form id=f1 action='http://localhost/wordpress/' method=post>
                      <input type=hidden name=id value=$result[sid]>
                    </form>
                   </body>";
echo "Sussusfull LOgin";

}
else {
echo "Un-Sussusfull LOgin";

}

?>
