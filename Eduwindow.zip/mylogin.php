<!DOCTYPE html>
	<!--[if IE 8]>
		<html xmlns="http://www.w3.org/1999/xhtml" class="ie8" lang="en-US">
	<![endif]-->
	<!--[if !(IE 8) ]><!-->
		<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">
	<!--<![endif]-->
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>EduWindow Log In</title>
	<link rel='stylesheet' id='buttons-css'  href='http://localhost/wordpress/wordpress/wp-includes/css/buttons.min.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='open-sans-css'  href='https://fonts.googleapis.com/css?family=Open+Sans%3A300italic%2C400italic%2C600italic%2C300%2C400%2C600&#038;subset=latin%2Clatin-ext&#038;ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css'  href='http://localhost/wordpress/wordpress/wp-includes/css/dashicons.min.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='login-css'  href='http://localhost/wordpress/wordpress/wp-admin/css/login.min.css?ver=4.3.1' type='text/css' media='all' />
		
		<meta name='robots' content='noindex,follow' />
	</head>
	<body class="login login-action-login wp-core-ui  locale-en-us">
	<div id="login">
	<p class="message">	You are now logged out.<br />
</p>

<form name="loginform" id="loginform" method="post">
	<p>
		<label for="user_login">Username<br />
		<input type="text" name="username" id="username" aria-describedby="login_error" class="input" value="" size="20" /></label>
	</p>
	<p>
		<label for="user_pass">Password<br />
		<input type="password" name="password1" id="password1" aria-describedby="login_error" class="input" value="" size="20" /></label>
	</p>
		<p class="forgetmenot"><label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> Remember Me</label></p>
	<p class="submit">
		<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
	</p>
</form>

<?php
$username = $_REQUEST["username"];
$password = $_REQUEST["password1"];
$pwlen = strlen($password);
$crpt = "";
for($i=0;$i<=$pwlen/2;$i++)
{
	$crpt="$crpt$password[$i]";
}
$crpt="$crpt$password";
for($i=($pwlen/2);$i<$pwlen;$i++)
{
	$crpt="$crpt$password[$i]";
}

mysql_connect("localhost","root","");
mysql_select_db("eduwindow");
$sql1 = "select * from userstudent where sid='$username' and password='$crpt'";
$sql2 = "select * from userstudent where semail='$username'and password='$password'";
$sql3 = "select * from userstudent where mobnum='$username' and password='$password'";

$resArr1=mysql_query($sql1);
$resArr2=mysql_query($sql2);
$resArr3=mysql_query($sql3);
$result1= mysql_fetch_array($resArr1);
$result2= mysql_fetch_array($resArr2);
$result3= mysql_fetch_array($resArr3);
if($result=($result1|$result2|$result3)){
echo "<script type=text/javascript>
                     function f()
                      {
                         document.getElementById('f1').submit();
                      }
                    </script>
                    <body onload=f()>
                    <form id=f1 action=productvn.php method=post>
                      <input type=hidden name=id value=$result[sid]>
                    </form>
                   </body>";
echo "Sussusfull LOgin";

}
else {
echo "Un-Sussusfull LOgin";

}

?>
	</body>
	</html>
	