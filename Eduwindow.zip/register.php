<?php
error_reporting(0);
mysql_connect("localhost","root","");
mysql_select_db("eduwindow");

$semail = $_REQUEST["remail"];
$mobnum = $_REQUEST["rmobnum"];
$password = $_REQUEST["rpassword"];
$sname = $_REQUEST["rusername"];
$place = $_REQUEST["raddress"];
$sid = $_REQUEST["admno"];

$pwlen = strlen($password);
$crpt = "";
for($i=0;$i<=$pwlen/2;$i++)
{
	$crpt="$crpt$password[$i]";
}
$crpt="$crpt$password";
for($i=($pwlen/2);$i<$pwlen;$i++)
{
	$crpt="$crpt$password[$i]";
}
$sql = "INSERT INTO `userstudent`(`sid`, `password`, `semail`, `mobnum`, `sname`, `place`) VALUES ('$sid','$crpt','$semail','$mobnum','$sname','$place')";

$resArr=mysql_query($sql);

if($resArr){
	echo "<script type=text/javascript>
                     function f()
                      {
                         document.getElementById('f1').submit();
                      }
                    </script>
                    <body onload=f()>
                    <form id=f1 action='http://localhost/wordpress/' method=post>
                      <input type=hidden name=id value=$result[sid]>
                    </form>
                   </body>";
echo "Sussusfull Insert";

}
else {
echo "Un-Sussusfull Insert";

}
echo $crpt;
?>